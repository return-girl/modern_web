$(function() {$("tr:even").addClass("even_style");$('table').each(function() {var click_th = $(this).find("thead tr th, thead tr td"),tbodys = $(this).find('tbody');make_Table_Sortable(click_th, tbodys);})});function make_Table_Sortable(click_th, tbodys) {click_th.click(function() {var arr = new Array();for (var j in tbodys[0].rows) arr[j] = tbodys[0].rows[j];changeClass(arr, $(this), click_th);tbodys.empty();tbodys.append(arr);$("tr").removeClass("even_style");$("tr:even").addClass("even_style");});}function changeClass(arr, th, click_th) {if (th.attr('class') != 'ascend' && th.attr('class') != 'descend') {$(click_th).removeAttr('class');th.attr('class', 'ascend');arr.sort(cmp(th[0].cellIndex));} else {th.attr('class', (th.hasClass('ascend') ? 'descend' : 'ascend'));arr.reverse();}}function cmp(col) {return function(x, y) {var xText = x.cells[col].textContent.toLowerCase(),yText = y.cells[col].textContent.toLowerCase();if (!isNaN(xText) && !isNaN(yText))return (xText - yText);return (xText > yText ? 1 : -1);}}

//那个评论无效的同学，我已经改进啦！！--
//亲测sicily有效

网站: http://soj.sysu.edu.cn/contests.php
      http://soj.sysu.edu.cn/courses.php
      http://soj.sysu.edu.cn/ranklist.php
